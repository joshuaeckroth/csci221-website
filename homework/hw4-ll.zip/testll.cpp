#include <iostream>
#include <cassert>
#include "linkedlist.h"
using namespace std;

int main()
{
    LinkedList *list = new LinkedList;
    assert(list->length() == 0);

    int *x0 = new int(5);
    list->push_back(x0);
    assert(list->length() == 1);


    cout << "End of main(). Success!" << endl;
}
